# JambuL AI Tools — APK Cloud Build

Wrapper Android WebView untuk aplikasi JambuL AI Tools.

URL:
https://preview-sandbox--6ac0d0556d402855f649432d.base44.app

Project ini sudah memiliki GitHub Actions untuk membangun APK di cloud.

Cara build dari HP:
1. Buat repository GitHub.
2. Upload semua isi folder project ini.
3. Buka Actions.
4. Pilih Build JambuL AI Tools APK.
5. Tekan Run workflow.
6. Setelah selesai, download artifact JambuL-AI-Tools-debug.
7. Di dalam ZIP artifact ada app-debug.apk.

APK debug untuk pengujian pribadi. Untuk Play Store, gunakan release signing/AAB.
